//
//  ABUCardViewProperty.h
//  Ads-Mediation-CN
//
//  Created by ByteDance on 2022/5/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUCardViewProperty : NSObject

@end

NS_ASSUME_NONNULL_END
